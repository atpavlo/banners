(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1920,250);


(lib.Image_1 = function() {
	this.initialize(img.Image_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1920,250);


(lib.Image_2 = function() {
	this.initialize(img.Image_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1920,250);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.voditelitext = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkWC0IAAglQgUgBgLgMQgLgMAAgTQAAgSALgMQAMgMATgBIAAgjIAMAAIAAAjQAUABALAMQALAMAAASQAAATgLAMQgKALgVACIAAAlgAkKCEQAPgBAHgJQAHgIAAgPQAAgdgdgDgAkrBMQgHAIAAAPQAAAOAHAKQAGAIAPABIAAhCQgOACgHAIgAn8C0IAAh7IALAAIACAMIAAAAQAFgHAHgDQAGgEAJAAQARAAAJAMQAJALAAAVQAAAWgJALQgJALgRAAQgIAAgHgDQgIgDgEgGIgBAAIABAOIAAAjgAnpBKQgGAHAAAPIAAADQAAASAGAIQAHAIAMAAQALAAAHgJQAGgJAAgQQAAgQgGgIQgHgJgLAAQgNAAgGAIgAFOCJQgHgHAAgMQAAgZApgCIAPAAIAAgFQAAgKgFgFQgEgFgJAAQgLAAgNAHIgEgKIANgGIAPgBQAQAAAHAGQAHAHAAAPIAAA6IgJAAIgDgMIgBAAQgHAIgFACQgGADgKAAQgNAAgHgGgAFxBlQgOAAgIAEQgGAFAAAIQAAAHAEAEQAFAEAHAAQAMAAAGgHQAHgGAAgMIAAgIgACXCKQgJgFgEgKQgFgKAAgOQAAgUAKgMQALgMASAAQASAAAKAMQALAMAAAUQAAAVgLAMQgKALgTAAQgLAAgJgFgACYBLQgGAIAAAQQAAARAHAIQAGAJANAAQAMAAAHgJQAGgIAAgRQAAgQgGgIQgHgJgMAAQgNAAgHAJgAggCEQgKgLAAgVQAAgVAKgMQALgMASAAQAGAAAGACIAJADIgEALIgJgDIgIgBQgaAAAAAhQAAAQAHAIQAGAIAMAAQAKAAALgEIAAALQgIAEgMAAQgTAAgKgLgAhrCEQgKgLAAgVQAAgWAKgLQAKgMATAAIAMACIAKADIgEALIgJgDIgJgBQgaAAAAAhQAAAQAGAIQAGAIANAAQALAAALgEIAAALQgJAEgNAAQgTAAgJgLgAjDCEQgLgLAAgVQAAgUAKgNQAKgMARAAQAQAAAJALQAJAKAAASIAAAIIg6AAQAAAPAIAHQAHAIANAAQANAAAOgGIAAAMIgNAEIgPABQgTAAgKgLgAi6BJQgFAGgCAMIAtAAQAAgMgGgGQgFgHgKAAQgKAAgHAHgAmNCKQgJgFgEgKQgFgKAAgOQAAgUAKgMQALgMASAAQASAAAKAMQALAMAAAUQAAAVgLAMQgKALgTAAQgLAAgJgFgAmLBLQgHAIAAAQQAAARAHAIQAGAJANAAQANAAAGgJQAGgIAAgRQAAgQgGgIQgGgJgNAAQgNAAgGAJgAGZCOIAAgKIAEABQAJAAAFgTQAFgRADgoIAyAAIAABVIgNAAIAAhKIgaAAQgCAfgDANQgEAPgGAIQgGAIgJAAQgFAAgCgBgAJSCOIAAhVIANAAIAABVgAIACOIAAhVIANAAIAAAjIAXAAQAQAAAIAGQAIAGAAAMQAAAMgJAHQgIAHgQAAgAINCDIAWAAQAUAAAAgOQAAgHgFgEQgEgDgMAAIgVAAgAElCOIAAgmIgvAAIAAAmIgNAAIAAhVIANAAIAAAjIAvAAIAAgjIANAAIAABVgABiCOIABhIIguBIIgQAAIAAhVIAMAAIAABEIgBAEIAuhIIAQAAIAABVgAokCOIAAhKIgtAAIAABKIgNAAIAAhVIBHAAIAABVgAlagkIAAgeIg8AAIAAAeIgMAAIAAgpIAHAAQAJgMAHgVQAGgSAAgWIArAAIAABJIAMAAIAAApgAmAhpQgFAQgJAMIAoAAIAAg/IgTAAQgCATgFAQgAiJhLQgKgMAAgUQAAgVAKgMQAKgMARAAQAQAAAJALQAJAKAAARIAAAIIg6AAQABAPAGAIQAIAIANAAQANAAAOgGIAAAMIgNAEQgGABgJAAQgSAAgMgLgAh/iGQgGAGgBAMIAtAAQAAgMgGgHQgGgGgJAAQgLAAgGAHgAnqhFQgIgGgFgKQgFgJAAgOQAAgWAKgKQALgMASAAQASAAAKAMQALAMAAAUQAAAVgLALQgKAMgSAAQgLAAgKgFgAnoiFQgHAIAAARQAAARAHAIQAHAIAMAAQAMAAAHgIQAHgJAAgQQAAgPgHgKQgGgIgNAAQgNAAgGAIgAhChBIAAgKIAEABQAIAAAGgTQAFgSADgnIAwAAIAABUIgMAAIAAhJIgZAAQgCAagEARQgDAQgHAIQgFAIgKAAgABhhCIAAhIIgtBIIgQAAIAAhUIAMAAIgBBEIAAAEIAuhIIAQAAIAABUgAjIhCIAAhJIgbAAIAAgLIBEAAIAAALIgcAAIAABJgAkAhCIABhIIguBIIgQAAIAAhUIAMAAIgBBIIAuhIIAQAAIAABUgApchCIAAhxIAgAAQAWAAALAHQAKAHAAAOQAAALgGAGQgGAHgKABIAAABQAZAFAAAWQAAAPgKAJQgKAIgTAAgApPhNIAYAAQANAAAHgFQAHgGAAgLQAAgKgHgFQgHgFgOAAIgXAAgApPiCIAWAAQAOAAAGgFQAGgDAAgLQAAgKgHgEQgGgEgPAAIgUAAgACBhmIAAgMIAmAAIAAAMg");
	this.shape.setTransform(60.7,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.voditelitext, new cjs.Rectangle(0,0,121.4,36), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AK/BEQgXgYAAgsQAAgsAXgXQAWgYApAAQAoAAAXAYQAWAYgBArQABAsgWAYQgWAYgpAAQgqAAgVgYgALbgsQgLAQAAAcQAAAdALAQQAMAPAXAAQAsAAABg8QgBg7gsAAQgXAAgMAPgAgmBSIAAggQAJAFASAEQAOADAOAAQAtAAAAgaQAAgLgPgHQgQgHgbAAIgPAAIAAgcIAOAAQAdAAAMgFQANgGAAgMQAAgKgIgFQgIgFgQAAQgZAAgXAOIgRgZQAQgKARgFQASgFATAAQAdAAARANQASAMAAAUQAAARgMALQgMALgWADIAAABQAaADAMAKQAOALAAASQgBAYgTAPQgUAOgkAAQgmAAgYgKgAjWBEQgWgYABgsQgBgsAWgXQAYgYAoAAQApAAAWAYQAVAXAAAsQABAtgWAXQgWAYgqAAQgpAAgWgYgAi5gsQgLAPAAAdQAAAeALAPQAMAPAWAAQAuAAAAg8QAAg7gtAAQgXAAgMAPgAN3BZIAAixIA4AAQAlAAASALQARAKAAAYQAAARgHAJQgIAKgMADIAAABQAQADAIAKQAIAKAAASQAAAYgSAOQgRANgfAAgAOdA6IAZAAQAQAAAHgGQAIgGAAgMQAAgWghAAIgXAAgAOdgRIAWAAQAQAAAHgFQAGgFAAgLQABgKgIgFQgHgEgRAAIgUAAgAJvBZIhBhZIAABZIglAAIAAixIAlAAIAABWIBBhWIAnAAIhBBWIBFBbgAG6BZIAAhVIACgyIgBAAIhTCHIgtAAIAAixIAiAAIgCCGIAAAAIBTiGIAuAAIAACxgADoBZIAAhFQgSAHgOACQgLACgNAAQgYAAgPgMQgNgMAAgVIAAhKIAlAAIAAA/QAAANAGAGQAGAGAPAAQAKAAAKgBQAHgBARgGIAAhQIAmAAIAACxgAmLBZIAAixIA3AAQAlAAASALQARAKABAYQgBARgHAJQgHAKgNADIAAABQARADAIAKQAHALAAARQAAAYgRAOQgTANgeAAgAllA6IAYAAQAPAAAIgGQAHgGAAgMQAAgWgfAAIgXAAgAllgRIAVAAQAQAAAHgFQAGgEABgMQAAgKgIgFQgHgEgRAAIgTAAgAoYBZIAAixIBoAAIAAAfIhCAAIAAAnIA9AAIAAAeIg9AAIAAAuIBCAAIAAAfgAq0BZIAAixIA4AAQAgAAASAOQARAOAAAcQAAAdgSAOQgSAPghAAIgQAAIAAA/gAqOgEIAMAAQARAAAJgHQAIgHAAgNQABgNgIgHQgHgGgPAAIgRAAgAtBBZIAAixIBoAAIAAAfIhCAAIAAAnIA8AAIAAAeIg8AAIAAAuIBCAAIAAAfgAuUBZIAAiSIhBAAIAACSIgmAAIAAixICNAAIAACxg");
	this.shape.setTransform(102,9.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,204,18.4), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhpB1IAAg1IhwAAIAAA1IgkAAIAAhUIAOAAQARghALgkQAKgkAEgpIBpAAIAACSIAYAAIAABUgAizgWQgLAjgJAUIBFAAIAAhyIgkAAQgFAfgIAcgARuBAIAAghQAMAEAPABQAKAAAHgGQAGgEAEgLIg+iAIApAAIAsBjIABAAIAnhjIAnAAIg4B9QgKAXgJALQgJAMgMAEQgNAFgSAAQgQAAgNgDgAKyAsQgUgXAAgtQAAgcAKgUQAJgUAUgMQATgMAZAAQAZAAAbANIgNAfIgUgIQgLgEgIAAQgVAAgMAQQgMAQABAdQAAA6AsABQATAAAagJIAAAfQgVAJgbAAQgoAAgUgXgAmZBAIAAghQAKAEARABQAKAAAFgGQAHgEAEgLIg9iAIAnAAIAsBjIABAAIAohjIAnAAIg3B9QgKAXgKALQgKAMgMAEQgLAFgTAAQgQAAgMgDgAtyAsQgWgZAAgrQAAgtAWgXQAWgYApAAQApAAAWAYQAWAYAAAsQAAArgWAZQgWAXgpAAQgqAAgVgXgAtVhFQgMAQAAAdQAAAdAMAPQAMAPAWABQAtgBAAg7QAAg8gtAAQgWAAgMAPgAwTAsQgUgXgBgtQAAgbALgVQAJgUAUgMQATgMAZAAQAaAAAaANIgLAfIgUgIQgMgEgJAAQgVAAgLAQQgNARAAAcQAAA6AtABQATAAAbgJIAAAfQgWAJgbAAQgnAAgVgXgAPVBAIAAixIA3AAQAlAAATALQARALAAAXQAAARgHAJQgIALgNACIAAABQASAEAHAKQAHALABAQQgBAZgRANQgRANgfAAgAP6AiIAZAAQAQgBAIgGQAHgFAAgNQAAgVggAAIgYAAgAP6gqIAXAAQAPAAAHgFQAHgEAAgLQAAgLgIgFQgHgEgQAAIgVAAgANjBAIAAiRIgxAAIAAggICHAAIAAAgIgwAAIAACRgAIZBAIAAixIBnAAIAAAfIhBAAIAAAnIA9AAIAAAgIg9AAIAAAtIBBAAIAAAegAHHBAIAAhEQgTAHgNABQgKADgNAAQgaAAgOgMQgOgMAAgWIAAhKIAmAAIAAA/QAAAOAGAFQAGAHAOAAQALAAAJgCQAJgCAQgFIAAhQIAlAAIAACxgAEUBAIAAhUQAAgVACgeIgBAAIhSCHIgtAAIAAixIAiAAIgDCGIACAAIBSiGIAtAAIAACxgABDBAIAAhLIhGAAIAABLIgmAAIAAixIAmAAIAABGIBGAAIAAhGIAmAAIAACxgAooBAIAAixIA4AAQAhAAARAOQARAOAAAcQAAAdgSAPQgSAOghAAIgQAAIAAA/gAoCgdIAMAAQASAAAIgGQAJgIAAgNQAAgMgIgIQgHgGgPAAIgRAAgAqaBAIAAiRIgwAAIAAggICGAAIAAAgIgxAAIAACRgAyiBAIhBhZIAABZIgmAAIAAixIAmAAIAABXIBAhXIApAAIhBBWIBEBbg");
	this.shape.setTransform(129,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,257.9,23.3), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjfBbQgLAAgHgDIAAgfQAJADAFAAQAGAAAEgGQADgGAEgQIAJg0QAFggAEglIBxAAIAACxIgmAAIAAiSIgrAAIgCARQgIA+gGAYQgGAagLAKQgJAKgSAAIgDAAgANrBYIACiKIgBAAIguCKIgjAAIgriLIgBAAIADCLIgiAAIAAixIAzAAIArCHIAAAAIAtiHIA0AAIAACxgAJEBYIAAixIBnAAIAAAfIhBAAIAAAnIA8AAIAAAeIg8AAIAAAuIBBAAIAAAfgAIFBYIgNgqIhBAAIgNAqIgpAAIA/iyIAuAAIA/CygAHAAOIAvAAIgYhMgACKBYIAAixIAmAAIAACSIA3AAIAAiSIAmAAIAACSIA3AAIAAiSIAmAAIAACxgABKBYIgMgqIhBAAIgNAqIgoAAIA+iyIAuAAIA/CygAAGAOIAuAAIgXhMIgXBMgAloBYIAAixIBwAAIAAAfIhLAAIAACSgAm3BYIACiHIgBAAIhTCHIgtAAIAAixIAiAAIgCCGIABAAIBSiGIAtAAIAACxgArTBYIAAixIA5AAQAfAAASAOQARAOAAAcQAAAdgSAOQgSAPghAAIgQAAIAAA/gAqtgFIAMAAQASAAAIgHQAJgHAAgNQAAgNgHgHQgIgGgPAAIgRAAgAsmBYIAAiSIhCAAIAACSIgmAAIAAixICOAAIAACxg");
	this.shape.setTransform(91.1,9.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,182.2,18.2), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFxArQgNgOAAgdQAAgQAGgOQAHgNALgHQALgHASAAQAQAAARAIIgIATIgMgFQgIgCgFAAQgNAAgIAKQgHAKgBARQABAmAcAAQAMAAAQgGIAAAUQgNAGgSAAQgYAAgNgPgAD0ArQgPgPAAgcQAAgbAPgPQAOgPAZAAQAbAAAOAPQANAPAAAbQAAAdgNAOQgOAPgbAAQgZAAgOgPgAEGgcQgHAKAAASQAAATAHAKQAIAJANAAQAdAAABgmQgBglgdAAQgNAAgIAJgAAUArQgMgPAAgcQgBgPAHgPQAHgNALgHQALgHASAAQAQAAAQAIIgHATIgNgFQgGgCgGAAQgOAAgIAKQgGAKgBARQAAAmAdAAQALAAASgGIAAAUQgOAGgSAAQgYAAgOgPgAlLArQgOgPAAgcQAAgbAOgPQAPgPAZAAQAaAAAOAPQAOAPAAAbQAAAdgOAOQgOAPgaAAQgZAAgPgPgAk4gcQgIAKAAASQAAATAIAKQAIAJANAAQAdAAAAgmQAAglgdAAQgNAAgIAJgAnAA0IAAgUQAJAEAIABQAIACAKAAQAcAAAAgQQABgIgJgEQgLgEgRAAIgKAAIAAgRIAJAAQARAAAKgEQAHgEABgHQgBgGgFgDQgEgEgLAAQgQAAgPAJIgKgQQALgHAJgCQALgDANAAQATAAAKAIQAMAHgBANQAAALgHAHQgIAHgNACIAAABQAQABAIAGQAIAHAAAMQAAAPgNAJQgMAJgXAAQgZAAgOgGgAIpA5IAAhwIAYAAIAAArIAKAAQAWAAAMAJQAMAIAAAQQAAAkgvAAgAJBAlIAJAAQAMAAAFgEQAGgDAAgJQAAgIgGgDQgFgDgOAAIgHAAgAHhA5IAAhcIgeAAIAAgUIBVAAIAAAUIgfAAIAABcgAC2A5IAAgxIgtAAIAAAxIgYAAIAAhwIAYAAIAAAsIAtAAIAAgsIAYAAIAABwgAgaA5IgIgbIgqAAIgIAbIgaAAIAohxIAdAAIApBxgAhGAKIAdAAIgMgpIgCgHgAiUA5IAAhcIgpAAIAABcIgZAAIAAhwIBaAAIAABwgAoTA5IAAhwIBBAAIAAATIgpAAIAAAZIAmAAIAAATIgmAAIAAAdIApAAIAAAUgAp4A5IAAhwIBHAAIAAATIgvAAIAAAYIAJAAQAXAAALAJQAMAIAAAQQAAAkguAAgApgAlIAIAAQAMAAAFgEQAGgDABgJQgBgIgGgDQgEgDgPAAIgGAAg");
	this.shape.setTransform(63.3,5.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,126.6,11.7), null);


(lib.strahppolis = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAIQgDgCAAgGQAAgEACgDQACgCAEgBQADABAEACQADADAAAEQAAAFgDACQgDADgEAAQgDAAgCgCg");
	this.shape.setTransform(113.7,32);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgbAwQgKgOAAgZQAAgaAIgQQAJgQARgEIAmgHIACALIglAHQgLADgGAJQgFAJgBARIABAAQAFgHAHgDQAIgEAHAAQAQAAAJAKQAIAIAAATQAAAVgKAKQgJALgTAAQgRAAgKgNgAgHgFIgKAGQgFAFgCADQAAAVAHAKQAGALAMAAQAYAAAAgeQAAgcgWAAQgEAAgGACg");
	this.shape_1.setTransform(106.9,26.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgmA8IAAgKIAKABQANAAAGgPIAEgMIgihUIAOAAIASAwQAHAPAAAIIABAAIAZhHIAOAAIglBfQgEANgHAHQgIAGgKAAg");
	this.shape_2.setTransform(98.2,30.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgkA+IAAh5IAKAAIACALIAAAAQAGgHAGgDQAHgDAHAAQARAAAJAMQAJALAAAUQAAAVgJALQgJALgRAAQgHAAgHgCQgHgEgFgGIgBAAIABAPIAAAigAgSgrQgGAHAAAQIAAACQAAASAGAHQAGAIAMAAQALAAAHgJQAGgIAAgQQAAgPgGgJQgHgIgLAAQgMAAgGAHg");
	this.shape_3.setTransform(89.6,30.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbArQgJgOAAgdQAAgcAJgPQAJgOASAAQASAAAKAPQAJAOAAAcQAAAdgJAPQgJAOgTAAQgSAAgJgPgAgSgjQgFALAAAYQAAAaAFAKQAGALAMAAQANAAAFgMQAGgLAAgYQAAgXgGgMQgFgLgNAAQgMAAgGALg");
	this.shape_4.setTransform(75.8,27.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgbArQgJgPAAgcQAAgcAJgPQAJgOASAAQATAAAJAPQAJAOAAAcQABAdgKAPQgJAOgTAAQgRAAgKgPgAgRgjQgHAMAAAXQAAAZAHALQAFALAMAAQAOAAAFgMQAFgLABgYQgBgXgFgMQgFgLgOAAQgMAAgFALg");
	this.shape_5.setTransform(66.8,27.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgbArQgKgPAAgcQAAgdAKgOQAJgOASAAQASAAAKAPQAKAOAAAcQAAAegKAOQgJAOgTAAQgSAAgJgPgAgSgjQgFAMAAAXQAAAZAFALQAHALALAAQANAAAFgMQAHgLgBgYQABgXgHgMQgFgLgNAAQgLAAgHALg");
	this.shape_6.setTransform(57.7,27.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgbArQgKgOAAgdQAAgcAJgPQAKgOASAAQATAAAIAPQAKAPAAAbQABAcgKAQQgJAOgTAAQgSAAgJgPgAgSgjQgGAMABAXQgBAYAGAMQAGALAMAAQANAAAFgMQAGgMAAgXQAAgXgGgMQgFgLgNAAQgMAAgGALg");
	this.shape_7.setTransform(44.6,27.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgbArQgJgOAAgdQAAgcAJgPQAJgOASAAQATAAAJAPQAJAOAAAcQAAAdgJAPQgJAOgTAAQgSAAgJgPgAgSgjQgFAMAAAXQAAAYAFAMQAGALAMAAQANAAAGgMQAFgMAAgXQAAgXgFgMQgGgLgNAAQgMAAgGALg");
	this.shape_8.setTransform(35.5,27.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbArQgJgOAAgdQAAgcAJgPQAJgOASAAQASAAAKAPQAJAOAAAcQAAAdgJAPQgJAOgTAAQgSAAgJgPgAgSgjQgFALAAAYQAAAaAFAKQAGALAMAAQANAAAFgMQAGgLAAgYQAAgXgGgMQgFgLgNAAQgMAAgGALg");
	this.shape_9.setTransform(26.4,27.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbArQgKgOAAgdQAAgdAKgOQAJgOASAAQASAAAKAPQAKAPAAAbQAAAegKAOQgJAOgTAAQgRAAgKgPgAgSgjQgFAMAAAXQAAAZAFALQAGALAMAAQANAAAGgMQAFgKAAgZQAAgYgFgLQgHgLgMAAQgMAAgGALg");
	this.shape_10.setTransform(13.3,27.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AANA5IAAgaIg2AAIAAgLIA0hMIAOAAIAABLIARAAIAAAMIgRAAIAAAagAAGgeIgiAxIApAAIAAg9IAAAAIgHAMg");
	this.shape_11.setTransform(4.2,27.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgTAgQgLgKABgVQgBgVALgMQAKgLASAAIAMABIAKADIgFAMIgJgEIgJgBQgZAAAAAhQABAPAGAJQAGAHALAAQAMABAKgFIAAALQgJAFgMAAQgSAAgJgMg");
	this.shape_12.setTransform(128.6,7.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAZArIAAhHIgtBHIgQAAIAAhVIAMAAIAABIIAthIIAQAAIAABVg");
	this.shape_13.setTransform(119.6,7.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AglAqIAAgJIAEAAQAJAAAFgTQAFgRADgnIAxAAIAABUIgNAAIAAhJIgZAAQgCAbgEAQQgEAQgFAHQgGAIgJAAg");
	this.shape_14.setTransform(109.5,7.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgTAmQgJgEgFgLQgFgKAAgNQAAgTAKgNQALgLARAAQASAAALAMQAKAMAAATQAAAVgKALQgLAMgSAAQgLAAgIgGgAgSgYQgHAKAAAOQAAAPAHAKQAGAIAMAAQANAAAGgIQAHgIAAgRQAAgPgHgJQgHgIgMAAQgMAAgGAIg");
	this.shape_15.setTransform(100.8,7.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAXArIAAhKIgtAAIAABKIgNAAIAAhVIBHAAIAABVg");
	this.shape_16.setTransform(91.1,7.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAZA8IAAhHIgtBHIgQAAIAAhUIAMAAIAABIIAthIIAQAAIAABUgAgUgoQgHgHgBgMIANAAQABAJADADQAEACAHAAQAIABAEgEQADgDABgIIANAAQgBANgHAFQgHAGgOAAQgNAAgHgFg");
	this.shape_17.setTransform(77,6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgUAmQgIgEgFgLQgFgKAAgNQAAgUAKgMQALgLARAAQASAAAKAMQALAMAAATQAAAVgLALQgKAMgSAAQgKAAgKgGgAgSgYQgHAJAAAPQAAARAHAIQAGAIAMAAQANAAAGgIQAHgKAAgPQAAgOgHgKQgHgIgMAAQgMAAgGAIg");
	this.shape_18.setTransform(67.2,7.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgjArIAAhVIAkAAQAgAAAAAWQAAAIgFAFQgEADgJACIAAABQALABAFAEQAFAGAAAIQAAAMgJAGQgJAHgQAAgAgWAfIAXAAQAWAAAAgOQAAgHgFgDQgGgDgMgBIgWAAgAgWgHIAWAAQALAAAFgCQAEgEAAgGQAAgGgEgCQgFgEgKAAIgXAAg");
	this.shape_19.setTransform(58.4,7.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgTAmQgKgEgEgLQgFgJAAgOQAAgTALgNQAKgLARAAQASAAALAMQAKAMAAATQAAAVgKALQgLAMgSAAQgKAAgJgGgAgSgYQgHAJABAPQAAARAGAIQAGAIAMAAQANAAAGgIQAHgIAAgRQAAgPgHgJQgHgIgMAAQgMAAgGAIg");
	this.shape_20.setTransform(48.7,7.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAYArIgYgjIgXAjIgPAAIAggrIgegqIAPAAIAVAhIAXghIAOAAIgeAqIAgArg");
	this.shape_21.setTransform(39.7,7.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgaAlQgHgGAAgMQAAgYAogCIAOAAIAAgGQAAgKgEgEQgEgFgKAAQgKAAgNAHIgDgKQAEgDAJgDIAOgCQAPAAAIAHQAHAHAAAOIAAA6IgKAAIgDgNIAAAAQgGAIgGADQgHADgIAAQgNAAgHgHgAAIACQgOAAgHAEQgHAFAAAIQAAAIAFACQAEAEAHABQAKAAAIgHQAHgHAAgLIAAgIg");
	this.shape_22.setTransform(30.9,7.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgkA+IAAh6IAKAAIACAMIABAAQAEgHAHgDQAHgDAHAAQARAAAJALQAJAMAAAVQAAATgJAMQgKAMgQAAQgHAAgHgDQgGgDgFgHIgBAAIABAxgAgRgrQgGAHAAAQIAAADQAAARAGAHQAGAIAMAAQALAAAGgJQAGgHAAgQQAAgRgGgIQgGgIgMAAQgMAAgFAHg");
	this.shape_23.setTransform(22.1,9.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgFArIAAhKIgcAAIAAgLIBDAAIAAALIgcAAIAABKg");
	this.shape_24.setTransform(13.4,7.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgcArQgOgPAAgcQAAgRAHgNQAGgNAMgHQANgHAPAAQARAAAPAGIgGAMQgNgGgNAAQgRAAgLAMQgLAMAAAVQAAAWALAMQAKAMASAAQAOAAANgEIAAAMQgMAEgRAAQgYAAgNgPg");
	this.shape_25.setTransform(4.9,6.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.strahppolis, new cjs.Rectangle(0,0,131.7,36.6), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EiV/ATiMAAAgnDMEr/AAAMAAAAnDg");
	mask.setTransform(960,125);

	// Layer_3
	this.instance = new lib.Image_2();
	this.instance.parent = this;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,1920,250), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EiV/ATiMAAAgnDMEr/AAAMAAAAnDg");
	mask_1.setTransform(960,125);

	// Layer_3
	this.instance_1 = new lib.Image_1();
	this.instance_1.parent = this;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(0,0,1920,250), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EiV/ATiMAAAgnDMEr/AAAMAAAAnDg");
	mask_2.setTransform(960,125);

	// Layer_3
	this.instance_2 = new lib.Image();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,250,1,1,0,180,0);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0.1,1920,250), null);


(lib.shieldicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai9DQQhBhTAAh+IAAjvID+hNID/BNIAADvQAAB+hBBTQhCBUh8AaQh7gahChUgAjojgIAADfQAAB1A7BNQA8BNBxAaQBygaA8hNQA7hNAAh1IAAjfIjphGgAhagVIASgRIBEBCICKiMIARARIibCeg");
	this.shape.setTransform(25.5,31.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.shieldicon, new cjs.Rectangle(0,0,51.1,63.7), null);


(lib.rabotaest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#46AC3D").s().p("AAuBaIgDgrIhAAAIgYArIgpAAIBsizIAuAAIATCzgAgDAPIAtAAIgEhNg");
	this.shape.setTransform(286.1,27.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#46AC3D").s().p("AAnB0IANg0IhvAAIgNA0IglAAIAVhUIAOAAQAcglASghQATgjAOgqIBpAAIglCTIAYAAIgVBUgAAAgYQgRAggRAYIBFAAIAdhzIgkAAQgLAbgRAgg");
	this.shape_1.setTransform(268.1,30.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#46AC3D").s().p("AhOBaIAsizIBxAAIgIAgIhKAAIglCTg");
	this.shape_2.setTransform(254.4,27.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#46AC3D").s().p("AhJBaIAtizIBmAAIgIAfIhBAAIgJAoIA8AAIgIAeIg8AAIgLAuIBAAAIgIAgg");
	this.shape_3.setTransform(239.8,27.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#46AC3D").s().p("AhHBEQgPgYALgsQAHgbAQgVQAPgVAWgLQAWgLAYAAQAaAAAYAMIgUAfIgSgIQgMgEgHAAQgWAAgPARQgPAPgIAdQgPA8AtAAQAQAAAfgKIgIAgQgXAJgbAAQgnAAgPgYg");
	this.shape_4.setTransform(225.4,27.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#46AC3D").s().p("AhRBaIAtizIA3AAQAmAAAOALQAPAKgGAZQgFARgJAJQgLALgMABIgBACQARADAEAKQAFAKgEASQgGAYgVAOQgVAOgeAAgAgjA6IAZAAQAOAAAJgGQAJgGAEgMQAFgWgfAAIgXAAgAgQgSIAVAAQAQAAAIgEQAIgFADgLQACgLgGgEQgGgFgRAAIgTAAg");
	this.shape_5.setTransform(207.7,27.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#46AC3D").s().p("AhGBaIAtizIAlAAIgQBFIAOAAQAjAAAPAOQAQAOgHAaQgOA4hJAAgAgYA7IANAAQARAAALgHQALgGADgMQADgNgIgFQgIgGgUAAIgKAAg");
	this.shape_6.setTransform(184,27.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#46AC3D").s().p("Ag7BaIAliTIgxAAIAIggICHAAIgIAgIgxAAIgkCTg");
	this.shape_7.setTransform(171.5,27.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#46AC3D").s().p("AhHBEQgPgYALgsQAHgbAQgVQAQgWAVgKQAVgLAaAAQAZAAAYAMIgUAfIgSgIQgLgEgIAAQgWAAgPARQgPAPgIAdQgPA8AtAAQAQAAAfgKIgIAgQgXAJgbAAQgnAAgPgYg");
	this.shape_8.setTransform(155.4,27.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#46AC3D").s().p("AhJBaIAtizIBmAAIgIAfIhBAAIgJAoIA8AAIgIAeIg8AAIgLAuIBAAAIgIAgg");
	this.shape_9.setTransform(139.7,27.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#46AC3D").s().p("AAtBaIgBgrIhBAAIgXArIgqAAIBrizIAvAAIATCzgAgEAPIAuAAIgEhNIgqBNg");
	this.shape_10.setTransform(114.9,27.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#46AC3D").s().p("Ag7BaIAliTIgxAAIAIggICGAAIgIAgIgwAAIgkCTg");
	this.shape_11.setTransform(103,27.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#46AC3D").s().p("AhPBEQgRgYAMgsQALgtAcgXQAbgXApAAQAqAAAQAXQAPAYgLAsQgKAsgdAYQgbAYgpAAQgpAAgQgYgAgWgtQgPAQgHAdQgIAeAIAPQAHAPAXAAQAtAAAPg8QAPg8guAAQgVAAgQAPg");
	this.shape_12.setTransform(83.9,27.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#46AC3D").s().p("AhOBaIAtizIBwAAIgIAgIhKAAIgJAlIAOAAQAjAAAPAOQAQAOgHAaQgOA4hJAAgAggA7IAMAAQATAAAKgHQALgGADgMQADgNgIgFQgIgGgVAAIgJAAg");
	this.shape_13.setTransform(65.8,27.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#46AC3D").s().p("AAuBaIgDgrIhAAAIgYArIgpAAIBsizIAuAAIATCzgAgDAPIAtAAIgEhNg");
	this.shape_14.setTransform(46.9,27.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#46AC3D").s().p("AhOBaIAtizIA4AAQAhAAAOAOQANAOgHAcQgHAdgWAPQgWAPggAAIgRAAIgQBAgAgQgEIANAAQAQAAALgHQAKgHADgNQAEgNgGgHQgGgHgPAAIgRAAg");
	this.shape_15.setTransform(32.6,27.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("A4hEDQgMAAgHgJQgHgJADgMIBynJQAEgMAKgJQALgJAMAAMAvDAAAQAMAAAHAJQAHAJgDAMIhyHJQgEAMgKAJQgLAJgNAAg");
	this.shape_16.setTransform(159.4,25.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.rabotaest, new cjs.Rectangle(0,0,318.9,51.8), null);


(lib.punctualitytext = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgnA5IAAhxIAYAAIAAAsIAKAAQAVAAAMAJQAMAIAAAQQAAAkguAAgAgPAlIAIAAQAMAAAFgEQAGgEAAgIQAAgHgGgEQgGgEgNAAIgGAAg");
	this.shape.setTransform(145.2,5.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLA5IAAhdIgfAAIAAgUIBVAAIAAAUIgfAAIAABdg");
	this.shape_1.setTransform(135.2,5.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdArQgNgOAAgdQAAgQAGgOQAHgNAMgHQAMgHAPAAQAQAAARAIIgIATIgNgFQgHgCgFAAQgMAAgIAKQgHAKAAARQgBAmAcAAQAMAAAQgGIAAAUQgNAGgRAAQgYAAgNgPg");
	this.shape_2.setTransform(125.8,5.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnArQgOgPAAgcQAAgbAOgPQAPgPAYAAQAaAAAOAPQAOAPAAAbQAAAdgOAOQgOAPgaAAQgYAAgPgPgAgVgcQgHAKAAASQAAATAHAJQAIAKANAAQAcAAABgmQgBglgcAAQgNAAgIAJg");
	this.shape_3.setTransform(114.3,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAXA5IAAgxIgsAAIAAAxIgYAAIAAhxIAYAAIAAAtIAsAAIAAgtIAXAAIAABxg");
	this.shape_4.setTransform(101.9,5.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgnA5IAAhxIAYAAIAAAsIAKAAQAVAAAMAJQAMAIAAAQQAAAkguAAgAgPAlIAIAAQAMAAAFgEQAGgEAAgIQAAgHgGgEQgGgEgNAAIgGAAg");
	this.shape_5.setTransform(91.1,5.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgyA4IAAgUIAIABQAFAAACgDQACgEACgKIAMhNIBGAAIAABxIgYAAIAAhcIgbAAIgBAKQgEAlgEASQgEAPgHAHQgHAGgMAAQgHAAgEgBg");
	this.shape_6.setTransform(79.2,5.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAdA5IgJgbIgoAAIgIAbIgZAAIAnhxIAcAAIApBxgAgOAKIAdAAIgPgwg");
	this.shape_7.setTransform(68.5,5.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgtA3IAAgUQAHACAJAAQAHAAAEgCQAEgEACgHIgnhRIAaAAIAaA/IABAAIAZg/IAZAAIgjBPQgHAQgGAHQgEAGgIADQgIAEgLgBQgJABgJgDg");
	this.shape_8.setTransform(57.8,5.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgLA5IAAhdIgfAAIAAgUIBVAAIAAAUIgfAAIAABdg");
	this.shape_9.setTransform(48.1,5.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AATA5Igog5IAAA5IgYAAIAAhxIAYAAIAAA3IAng3IAaAAIgpA3IArA6g");
	this.shape_10.setTransform(38.9,5.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAWA5IAAgxIgrAAIAAAxIgYAAIAAhxIAYAAIAAAtIArAAIAAgtIAYAAIAABxg");
	this.shape_11.setTransform(26.8,5.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgtA3IAAgUQAGACALAAQAFAAAFgCQADgDAEgIIgohRIAaAAIAaA/IABAAIABgEIAYg7IAZAAIgjBPQgGAPgHAIQgEAGgIADQgHAEgMgBQgKABgIgDg");
	this.shape_12.setTransform(15.6,5.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAVA5IAAhdIgpAAIAABdIgYAAIAAhxIBZAAIAABxg");
	this.shape_13.setTransform(4.5,5.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.punctualitytext, new cjs.Rectangle(0,0,149.2,11.7), null);


(lib.plashka1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#46AC3D").s().p("Eg8eALhIAA3BMB3JAAAQA+AAAgAsQAhAsgPA9IkoSXQgQA9g2AsQg3Asg+AAg");
	this.shape.setTransform(387.1,73.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.plashka1, new cjs.Rectangle(0,0,774.3,147.4), null);


(lib.plashka = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3EB549").s().p("EhOhALhQg+AAgggsQghgsAPg9IEoyXQAQg9A2gsQA3gsA9AAMCZFAAAIAAXBg");
	this.shape.setTransform(514.3,73.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.plashka, new cjs.Rectangle(0,0,1028.5,147.4), null);


(lib.phone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhbBkIAKgoQAKAGAPAEQAPAEAOAAQAqAAAJgjQAIghgsAAIgSABIgRAEIgQgKIAkhwIB3AAIgKAoIhPAAIgNArIAFgBQAJgCAOAAQAgAAAOASQAPARgHAfQgJAlgcAUQgbAUgqAAQglAAgUgMg");
	this.shape.setTransform(242.5,24.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgHBvIAKguIhdAAIAIghICCiOIArAAIghCLIAaAAIgJAkIgaAAIgLAugAAOggIg2A9IA0AAIAJglIAHgbIAGgVIgBAAQgIAMgLAMg");
	this.shape_1.setTransform(224.6,24.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhBBmQgQgLgEgWQgFgWAHgfQAQhAAkghQAigfA4AAQATAAAKACIgJAlQgNgCgNAAQgYgBgRAIQgQAHgLAOQgMAOgGAaIACAAQAUgZAhAAQAdgBANAUQALARgHAhQgJAjgZAVQgYAVgjAAQgZAAgPgMgAgYAMQgNAJgDAMQgEASAGAMQAHANAPAAQAPAAAIgKQALgKAFgTQAEgQgGgJQgFgKgPABQgNgBgMAKg");
	this.shape_2.setTransform(199.8,24.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhdBmIAKgoQALAHAOAEQAPAEAPAAQAXAAAMgIQANgIAEgRQAEgQgLgHQgLgGgbAAIgRAAIAJgjIARAAQAYAAAOgHQAOgGAEgRQAGgZggAAQgLAAgLAEQgMADgQAJIgOggQAkgWApAAQAiAAAQAOQARAOgGAZQgFAVgQAOQgQAPgYAFIAAABQAaADAKAMQALANgFAWQgIAggbASQgcASgqAAQgkAAgZgMg");
	this.shape_3.setTransform(181.2,24.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhbBkIAKgoQAKAGAPAEQAPAEAOAAQAqAAAJgjQAIghgsAAIgSABIgRAEIgQgKIAkhwIB3AAIgKAoIhPAAIgNArIAFgBQAJgCAOAAQAgAAAOASQAPARgHAfQgJAlgcAUQgbAUgqAAQglAAgUgMg");
	this.shape_4.setTransform(155.6,24.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AheBwIAIggIBFg4IAogiQAKgKAFgJQAFgIADgJQADgNgGgHQgGgGgMAAQgNAAgNAGQgNAGgQALIgSgfQAUgOAMgFQAMgGANgDQANgDAQAAQAUAAAOAHQAPAIAFAOQAGANgFASQgDAPgJANQgJAOgOANQgPAOgjAaIgiAbIAAACIBfAAIgJAng");
	this.shape_5.setTransform(137.7,23.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhBBmQgQgLgEgWQgFgWAHgfQARhAAjghQAigfA4AAQATAAAKACIgJAlQgNgCgNAAQgYgBgRAIQgQAHgLAOQgMAOgGAaIACAAQAUgZAhAAQAdgBAMAUQAMARgHAhQgJAjgZAVQgYAVgjAAQgZAAgPgMgAgYAMQgNAJgDAMQgEASAGAMQAHANAOAAQAQAAAIgKQALgKAFgTQAEgQgGgJQgFgKgQABQgNgBgLAKg");
	this.shape_6.setTransform(121,24.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhbBkIAKgoQAKAGAPAEQAPAEAOAAQAqAAAJgjQAIghgsAAIgSABIgRAEIgQgKIAkhwIB3AAIgKAoIhPAAIgNArIAFgBQAJgCAOAAQAgAAAOASQAPARgHAfQgJAlgcAUQgbAUgqAAQglAAgUgMg");
	this.shape_7.setTransform(94.4,24.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhBBmQgQgLgEgWQgFgWAHgfQARhAAjghQAigfA4AAQATAAAKACIgJAlQgNgCgNAAQgYgBgRAIQgQAHgLAOQgMAOgGAaIABAAQAWgZAgAAQAdgBANAUQAMARgJAhQgIAjgZAVQgYAVgjAAQgZAAgPgMgAgYAMQgNAJgDAMQgFASAHAMQAHANAPAAQAPAAAIgKQALgKAEgTQAEgQgFgJQgFgKgPABQgNgBgMAKg");
	this.shape_8.setTransform(77.5,24.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhXBwIAJgmQAMADAOAAQAXAAARgHQAQgHAMgOQALgPAHgaIgCAAQgLAOgNAGQgMAFgSAAQgcABgNgTQgMgRAIgiQAJgjAZgVQAZgVAiABQAYAAAQALQAQALAEAXQAFAVgIAeQgPBBgkAgQgiAhg4AAQgTAAgKgCgAgGhBQgLAKgFATQgEAQAGAJQAFAKAPAAQANAAANgKQAMgJADgMQAEgSgGgNQgGgMgPAAQgPAAgJAKg");
	this.shape_9.setTransform(59.4,24.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhcBvIB+i1IhsAAIAJgnICeAAIgHAdIiBC/g");
	this.shape_10.setTransform(35.1,24.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgiBLIAPg6Ig7AAIAIggIA7AAIAMg7IAiAAIgPA7IA7AAIgIAgIg7AAIgMA6g");
	this.shape_11.setTransform(16.2,24.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone, new cjs.Rectangle(0,0,260,46.3), null);


(lib.otvetstvennost = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgnA5IAAhxIAYAAIAAAsIAKAAQAVAAAMAJQAMAIAAAQQAAAjguABgAgPAlIAIAAQALAAAGgEQAGgEAAgIQAAgHgGgEQgFgEgOAAIgGAAg");
	this.shape.setTransform(149.8,5.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLA5IAAhcIgfAAIAAgVIBVAAIAAAVIgfAAIAABcg");
	this.shape_1.setTransform(139.8,5.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdArQgNgPAAgcQAAgRAGgNQAHgOALgGQANgHAPAAQARAAAQAIIgIATIgMgFQgHgCgGAAQgNAAgHAKQgHAKgBASQABAlAbAAQAMAAAQgGIAAAVQgOAFgRAAQgXAAgNgPg");
	this.shape_2.setTransform(130.4,5.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnArQgOgPAAgcQAAgbAOgPQAOgPAZAAQAaAAAOAPQAOAPAAAbQAAAcgOAPQgOAPgaAAQgZAAgOgPgAgVgbQgGAKAAARQAAAUAGAJQAIAJANAAQAcAAABgmQgBglgcAAQgNAAgIAKg");
	this.shape_3.setTransform(118.9,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAXA5IAAgxIgsAAIAAAxIgYAAIAAhxIAYAAIAAAtIAsAAIAAgtIAXAAIAABxg");
	this.shape_4.setTransform(106.5,5.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAWA5IAAgxIgrAAIAAAxIgYAAIAAhxIAYAAIAAAtIArAAIAAgtIAYAAIAABxg");
	this.shape_5.setTransform(94.4,5.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AggA5IAAhxIBBAAIAAAUIgpAAIAAAZIAmAAIAAATIgmAAIAAAdIApAAIAAAUg");
	this.shape_6.setTransform(84.1,5.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpA5IAAhxIAjAAQAXABALAGQALAIAAAOQAAAKgEAHQgFAGgIABIAAABQAKACAFAGQAFAHAAALQAAAPgLAJQgMAIgTABgAgRAlIAQAAQAJAAAEgEQAFgDAAgJQAAgNgTAAIgPAAgAgRgLIAOAAQAJAAAEgDQAEgCABgIQAAgGgFgDQgFgDgJAAIgNAAg");
	this.shape_7.setTransform(74.4,5.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLA5IAAhcIgfAAIAAgVIBVAAIAAAVIgfAAIAABcg");
	this.shape_8.setTransform(64.2,5.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgdArQgNgQAAgbQAAgRAHgNQAFgNANgHQAMgHAPAAQARAAAQAIIgHATIgOgFQgFgCgHAAQgNAAgHAKQgIAKABASQAAAlAbAAQAMAAARgGIAAAVQgPAFgQAAQgYAAgNgPg");
	this.shape_9.setTransform(54.8,5.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgLA5IAAhcIgfAAIAAgVIBUAAIAAAVIgeAAIAABcg");
	this.shape_10.setTransform(45,5.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggA5IAAhxIBBAAIAAAUIgpAAIAAAZIAmAAIAAATIgmAAIAAAdIApAAIAAAUg");
	this.shape_11.setTransform(36.2,5.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgpA5IAAhxIAjAAQAXABALAGQALAIAAAOQAAAKgFAHQgEAGgIABIAAABQAKACAFAGQAFAHAAALQAAAPgLAJQgLAIgUABgAgRAlIAQAAQAIAAAGgEQAEgDAAgJQAAgNgTAAIgPAAgAgRgLIAOAAQAJAAAEgDQAFgCAAgIQgBgGgEgDQgFgDgJAAIgNAAg");
	this.shape_12.setTransform(26.5,5.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgLA5IAAhcIgfAAIAAgVIBVAAIAAAVIgfAAIAABcg");
	this.shape_13.setTransform(16.3,5.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgnArQgOgOAAgdQAAgbAOgPQAOgPAZAAQAaAAAOAPQAOAPAAAbQAAAdgOAOQgOAPgaAAQgZAAgOgPgAgUgbQgIAKAAARQAAATAHAKQAIAJANAAQAdAAAAgmQAAglgdAAQgNAAgHAKg");
	this.shape_14.setTransform(5.4,5.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.otvetstvennost, new cjs.Rectangle(0,0,153.8,11.7), null);


(lib.otvicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai6E+QgfAAgVgVQgWgWAAgfIAAnoQAAgeAWgWQAVgVAfAAIF1AAQAeAAAWAVQAWAWAAAeIAAHoQAAAfgWAWQgVAVgfAAgAjfkYQgPAPAAAVIAAHoQAAAWAPAPQAPAPAWAAIF1AAQAWAAAPgPQAPgPAAgWIAAnoQAAgVgPgPQgQgPgVAAIl1AAQgWAAgPAPgAiLBqICPiGIAAgBIASgQIBSBWIgSARIhBhEIiPCGg");
	this.shape.setTransform(26.1,31.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.otvicon, new cjs.Rectangle(0,0,52.2,63.7), null);


(lib.oteurofuru = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#46AC3D").s().p("AAfBaIAtizIAmAAIgtCzgAhwBaIAsizIAmAAIgRBFIAMAAQAjAAAOAOQAQAOgHAaQgGAbgWAPQgXAOgkAAgAhDA7IAKAAQATAAAKgHQAKgGAEgMQADgNgIgFQgGgGgWAAIgIAAg");
	this.shape.setTransform(216.4,27.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#46AC3D").s().p("AhOBaIAtizIA4AAQAhAAAOAOQANAOgHAcQgHAdgWAPQgWAPggAAIgRAAIgQBAgAgQgEIANAAQAQAAALgHQAKgHADgNQAEgNgGgHQgGgHgPAAIgRAAg");
	this.shape_1.setTransform(197.1,27.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#46AC3D").s().p("AhjBXIAIggQAKAEAQAAQAKAAAHgEQAIgGAHgLIgeiAIAoAAIATBjIACAAIA/hjIAnAAIhXB+QgQAZgLAKQgMAJgOAGQgPAFgQAAQgPAAgNgEg");
	this.shape_2.setTransform(181.5,27.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#46AC3D").s().p("AgoBcIAHgbIgDAAQgWAAgQgIQgPgJgGgQQgGgQAFgSQAFgTANgQQAMgPATgIQATgJAWAAIAGAAIAFgWIAiAAIgFAWIAGAAQAWAAAPAJQAPAIAEAPQAFAQgEATQgGATgNAPQgNAQgUAJQgUAIgWAAIgDAAIgGAbgAAHAjIACAAQAUAAAOgKQAOgLAEgRQAEgRgIgJQgHgKgTAAIgFAAgAgrgdQgNAKgEAQQgEASAIAKQAJAKAUAAIABAAIAThKIgFAAQgTAAgMAKg");
	this.shape_3.setTransform(162.1,27.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#46AC3D").s().p("AhQBEQgQgYAMgsQALgtAcgXQAbgXAqAAQApAAAPAXQAQAZgKArQgMAtgcAXQgcAYgoAAQgpAAgRgYgAgVgtQgQAQgIAdQgHAeAHAPQAIAPAXAAQAsAAAPg8QAPg8gtAAQgWAAgOAPg");
	this.shape_4.setTransform(141.3,27.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#46AC3D").s().p("AhNBaIAsizIA5AAQAhAAANAOQANAOgHAcQgGAcgXAQQgVAPghAAIgQAAIgQBAgAgQgEIANAAQAQAAALgHQAKgHAEgNQADgOgGgGQgGgHgPAAIgQAAg");
	this.shape_5.setTransform(123.3,27.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#46AC3D").s().p("AhRBaIAtizIA3AAQAnAAAOALQAOALgGAYQgDAPgLALQgLALgMABIAAACQAQADAFAKQAFAKgFASQgGAYgVAOQgVAOgeAAgAgjA6IAZAAQAPAAAJgGQAJgGADgMQAFgWgfAAIgXAAgAgQgSIAWAAQAPAAAIgEQAJgGACgKQADgKgHgFQgGgFgRAAIgTAAg");
	this.shape_6.setTransform(106.8,27.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#46AC3D").s().p("AhJBaIAtizIBmAAIgIAfIhBAAIgJAoIA8AAIgIAeIg7AAIgNAuIBBAAIgIAgg");
	this.shape_7.setTransform(92,27.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#46AC3D").s().p("AggBaIAjiLIgoAdIgMgXIBEguIAfAAIgtCzg");
	this.shape_8.setTransform(71.3,27.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#46AC3D").s().p("Ag7BaIAliTIgxAAIAIggICGAAIgIAgIgwAAIgkCTg");
	this.shape_9.setTransform(51.7,27.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#46AC3D").s().p("AhPBEQgRgYAMgsQALgtAcgXQAbgXApAAQAqAAAQAXQAPAYgKAsQgMAtgcAXQgbAYgpAAQgpAAgQgYgAgWgtQgPAQgHAdQgIAeAIAPQAHAPAXAAQAtAAAPg8QAPg8gtAAQgWAAgQAPg");
	this.shape_10.setTransform(32.6,27.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AzWEDQgMAAgGgJQgIgJADgMIB1nJQADgMALgJQAKgJANAAMAkpAAAQANAAAGAJQAIAJgDAMIh1HJQgDAMgLAJQgLAJgMAAg");
	this.shape_11.setTransform(126.3,25.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.oteurofuru, new cjs.Rectangle(0,0,252.5,51.8), null);


(lib.lastSlidePlashka = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#46AC3D").s().p("EhOhALhQg+AAgggsQghgsAPg9IEoyXQAQg9A2gsQA3gsA9AAMCZFAAAIAAXBg");
	this.shape.setTransform(514.3,73.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.lastSlidePlashka, new cjs.Rectangle(0,0,1028.5,147.4), null);


(lib.lastSlideLogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A8qFBQgIAAgEgGQgEgGACgIIAXhaQACgIAHgGQAHgGAIAAIB7AAIAAgBIAJghIkKAAQgRAAgJgNQgJgNAFgSIAyjBQADgOANgOIiWAAQACAIgCAJIgmCRIgEAKIA8AAQAFAAACADQACAEgBAEIgNAyQgBAEgEAEQgEADgEAAIhFAAQgEAAgCgDQgCgEABgEIAKgoQgHADgFAAIjLAAQgNAAgHgKQgHgKAEgOIAliRIABgBIhbAAIgPA6QgCAHgFAEQgFAEgGAAIhbAAQgFAAgDgEQgDgEABgHIARhBQACgGAFgEQAFgFAGAAIBOAAIAUhPQACgHAHgGQAGgFAHAAIByAAQAHAAAEAFQAEAGgCAHIgSBFIDMAAIAGAAIABgIIAchsIADgIIg4AAQgFAAgCgEQgCgDABgFIANgxQABgFAEgDQAEgDAEAAIBFAAQAEAAACADQACADgBAFIgLAsICVAAQAKAAAFAHQAFAIgDAKIgcBsQAAAFgEAFIALgBIERAAIAQg8IgoAAQgGAAABgHIAIgfQACgHAHAAIAsAAQAAAAABAAQABAAAAAAQABABAAAAQAAAAABABQABACAAADIgHAYQAEgCAFAAIB8AAQAIAAAFAGQAEAFgCAJIgYBaIgBAEIA/AAIAHgaQACgHAGAAIAsAAQAHAAgCAHIgIAgQgCAHgHAAIgpAAIgMAwQgBAEgEAEQgEADgFAAIhEAAQgEAAgDgDQgCgEABgEIAMgtIhtAAIgwC6IAyAAQAGAAACAEQADAEgBAGIgQA7QgBAGgFAEQgFAEgFAAIhMAAIAAAHIgXBaQgCAIgIAGQgHAGgIAAgANYEBIAFgSIhCAAIAUhUIAJAAIgSBMIAyAAIAShMIAJAAIgSBMIAGAAIgGAagAJ4EBIAEgSIg8AAIgEASIgJAAIAHgaIAEAAIAGgGIAGgKQADgGABgGIALgwIA6AAIgSBMIAGAAIgGAagAJTDYIgFAKQgDAEgDABIAvAAIAQhEIgmAAgAbCDvQgGgCgCgFQgDgDAAgKQAAgGAEgQQADgNAEgJQADgJAFgEQAFgFAGgBQAHgCAKAAQAKAAAGACQAFABADAFQADAFgBAIQAAAHgDAPQgDANgEAJQgEAJgFAEQgEAEgHADQgGACgKAAQgLAAgFgCgAbUClQgGADgDAHQgCAFgFARIgDASQgBAGACAEQABAEAEACQAFABAHAAQAIAAAFgBQAFgCADgDQAEgEACgHIAFgSQAEgOAAgIQAAgHgEgDQgFgDgKAAQgKAAgGADgAQLDvQgGgCgCgFQgDgDAAgKQAAgGAEgQQADgNAEgJQADgJAFgEQAFgFAGgBQAHgCAKAAQAKAAAGACQAFABADAFQADAFgBAIQAAAHgDAPQgDANgEAJQgDAHgGAGQgEAEgHADQgGACgKAAQgLAAgFgCgAQdClQgGADgDAHQgCAFgFARIgDASQgBAGACAEQABAEAEACQAFABAHAAQAIAAAFgBQAFgCADgDQAEgEACgHIAFgSQAEgOAAgIQAAgHgEgDQgFgDgKAAQgKAAgGADgAjhDvQgGgCgDgFQgCgFAAgIQAAgJAEgNQADgNAEgJQACgHAGgGQAGgFAFgBQAHgCAKAAQAKAAAGACQAFABADAFQACAEAAAJIgDAWQgFARgCAFQgEAJgFAEQgEAEgHADQgGACgLAAQgKAAgFgCgAjPClQgGADgDAHQgEAJgDANIgDASQgBAGACAEQABAEAEACQAFABAHAAQAIAAAFgBQAGgCACgDQADgDADgIIAFgSIAEgWQAAgHgEgDQgFgDgKAAQgKAAgGADgAp5DvQgFgCgDgFQgDgDAAgKIAEgWQAEgRADgFQADgHAFgGQAFgFAHgBQAHgCAJAAQALAAAFACQAFABADAFQADAGgBAHQAAAKgDAMQgEAPgDAHQgDAHgFAGQgFAFgHACQgGACgKAAQgLAAgFgCgApnClQgGADgDAHQgDAIgEAOIgDASQgBAHACADQABAEAFACQAEABAIAAQAIAAAEgBQAFgCAEgDQADgFACgGQAEgIABgKQAEgOAAgIQAAgHgEgDQgFgDgKAAQgKAAgGADgAEcDvQgGgDgCgEQgDgFAAgIQAAgJAEgMQACgKAEgMQAEgIAFgFQAFgEAHgDQAHgBAJAAQAPAAAFACQAGADABAGQABAEgCAMIgJAAIABgKQAAgDgCgCQgCgCgEgBIgMgBQgHAAgFABQgGACgCADQgEAEgDAHIgFASIgDARQAAAHABAEQACADAEACQAFABAHAAIANgBQAEAAAEgDQADgDACgDQACgDABgIIAJAAIgEAOQgDAGgFADQgEADgHACQgHABgKAAQgKAAgGgBgABLDuQgHgDgCgFQgCgFADgMIAJAAQgCAIACAEQABAEAFACQAEABAKAAQAJAAAEgCQAFgBADgEQAEgDACgGIAEgQIgrAAIACgIIArAAQADgLgBgHQgBgGgEgDQgFgCgJAAQgJAAgFABQgFACgDADIgFALIgJAAIAFgNQADgFAFgCQAFgEAFAAIAPgBQAKAAAGABQAFACAEAFQACAFAAAHQgBALgDAMQgDAOgDAHQgEAJgFAEQgFAFgGACQgHABgKAAQgNAAgGgCgAtMDvQgGgDgDgEQgDgFAAgIIAEgVQAEgQADgGQAEgIAEgFQAEgEAIgDQAHgBAKAAQAOAAAFACQAGADABAGQABAEgBAMIgKAAIABgKQAAgCgCgDQgBgCgFgBIgLgBQgHAAgGABQgFACgDADIgGALIgGASIgDARQAAAHACAEQABADAFACQAEABAHAAIANgBQADAAAFgDIAFgGIAEgLIAJAAIgFAOQgEAGgDADQgEADgIACQgGABgLAAQgKAAgFgBgEAmNADvIAIghIgaAAIgbAhIgLAAIAcgjQgJgDgDgGQgDgGACgJQACgJAEgGQADgEAIgEQAHgCAJAAIAlAAIgUBUgEAl0ACoQgFAFgCAJQgCAIAEAEQAFAEAJAAIAaAAIAIgjIgeAAQgJAAgEAFgEAklADvIAShNIhCBNIgPAAIAUhUIAJAAIgSBOIBChOIAPAAIgTBUgEAi0ADvIAJgmIgyAAIgJAmIgJAAIAUhUIAJAAIgJAlIAyAAIAJglIAJAAIgUBUgEAhLADvIgDgRIgqAAIgLARIgKAAIAzhUIANAAIAMBUgEAgiADWIAmAAIgHg0gAfbDvIAShMIgxAAIgSBMIgJAAIAUhUIBEAAIgUBUgAduDvIAShNIgyBNIgKAAIgOhMIgSBMIgKAAIAUhUIARAAIANBIIAuhIIARAAIgUBUgAaCDvIgdgnIgIAAIgKAnIgJAAIAUhUIAJAAIgIAlIAIAAIArglIANAAIgxApIAhArgAXeDvIAIghIgaAAIgbAhIgLAAIAcgjQgIgDgEgGQgDgFACgKQACgIAEgHQAFgFAGgDQAIgCAIAAIAmAAIgUBUgAXFCoQgEAEgDAKQgCAHAFAFQAEAEAKAAIAZAAIAIgjIgeAAQgJAAgEAFgAV8DvIgDgRIgqAAIgLARIgKAAIAyhUIAOAAIAMBUgAVTDWIAlAAIgGg0gAUMDvIAJgmIgxAAIgJAmIgKAAIAUhUIAKAAIgJAlIAxAAIAJglIAJAAIgUBUgASeDvIAJgmIgxAAIgJAmIgJAAIAUhUIAJAAIgJAlIAxAAIAJglIAKAAIgUBUgAPIDvIAShNIhCBNIgPAAIAUhUIAJAAIgSBOIBChOIAPAAIgUBUgALoDvIAShNIhCBNIgPAAIAUhUIAJAAIgSBOIBChOIAPAAIgUBUgAHfDvIAUhUIA3AAIgCAIIgtAAIgHAdIArAAIgCAIIgrAAIgHAfIAtAAIgCAIgAGtDvIAShMIgxAAIgSBMIgKAAIAUhUIBEAAIgUBUgADeDvIgdgnIgIAAIgKAnIgJAAIAUhUIAJAAIgIAlIAIAAIArglIANAAIgxApIAhArgAkkDvIAJgmIgxAAIgJAmIgKAAIAUhUIAJAAIgIAlIAxAAIAJglIAJAAIgUBUgAmnDvIAShMIgcAAIACgIIBBAAIgCAIIgcAAIgSBMgAohDvIAUhUIApAAQAMAAADAGQAEAFgCANQgDALgEAFQgEAGgHADQgGACgLAAIgaAAIgHAhgAoNDGIAWAAQAIAAAFgBQAEgBAEgEQACgDADgIQACgKgCgEQgDgEgHAAIgeAAgAq8DvIAShMIgxAAIgSBMIgJAAIAUhUIBEAAIgUBUgAuODvIAKgmIgyAAIgJAmIgJAAIAUhUIAJAAIgJAlIAyAAIAIglIAKAAIgUBUgAv2DvIgDgRIgqAAIgLARIgKAAIAyhUIAOAAIAMBUgAwfDWIAlAAIgGg0gAyYDvIAUhUIApAAQALAAAEAGQAEAFgDANQgCALgEAFQgFAHgGACQgGACgLAAIgaAAIgHAhgAyEDGIAWAAQAIAAAFgBQAEgBAEgEQACgDADgIQACgKgCgEQgDgEgHAAIgeAAgAzfDvIAShMIgcAAIACgIIBAAAIgCAIIgbAAIgSBMgAhMDHIABgFIA6AAIgBAFgEAjeAA9IAThOIiEAAQgNAAgHgJQgHgJADgNIAdh3QAEgOALgIQALgKANAAIE7AAQAOAAAGAKQAHAIgDAOIgdB3QgDANgLAJQgLAJgOAAIiAAAIgTBOgEAk2gBIIBYAAQAGAAAGgFQAGgFACgGIAJgoQACgGgEgFQgDgEgHAAIhYAAgEAingCLQgGAGgBAFIgKAoQgBAGADAFQADAFAHAAIBcAAIARhHIhcAAQgGAAgGAEgAccA9IA3jkQAEgOALgIQALgKAOAAIDFAAQAOAAAHAKQAHAJgEANIgcB3QgDANgMAJQgLAJgNAAIiuAAIgUBOgAeJiLQgGAGgCAFIgJAoQgCAGAEAFQADAFAHAAIB2AAQAHAAAGgFQAFgFACgGIAKgoQABgFgDgGQgEgEgHAAIh2AAQgHAAgFAEgAbGA9IANg3IA8AAIgOA3gAXFA9QgNAAgHgJQgHgKADgMIAwjFQADgNALgJQALgKAOAAIDlAAIgNA4Ii+AAQgHAAgFAEQgFAFgDAGIgcB3QgCAHAEADQAEAFAGAAIC+AAIgOA3gAVNA9IAVhWQABgGgDgFQgEgFgGAAIh3AAQgGAAgGAFQgGAFgCAGIgUBWIg4AAIA/kEIA4AAIgVBXQgBAHADAEQAEAFAGAAIB3AAQAGAAAGgFQAGgEABgHIAVhXIA3AAIg+EEgAQpA9IgGgmIhpAAIgYAmIg/AAICekEIA/AAIAoEEgAPbgfIA/AAIgMhUgAJJA9IA3jkQADgNAMgJQALgKANAAIDGAAQAOAAAHAKQAHAJgEANIgcB3QgDANgMAJQgLAJgNAAIiuAAIgUBOgAK1iLQgFAGgCAFIgJAoQgCAGAEAFQADAFAHAAIB2AAQAHAAAGgFQAFgFACgGIAJgoQACgFgDgGQgEgEgHAAIh2AAQgHAAgGAEgAGaA9IAui9QABgFgDgGQgEgEgHAAIhXAAIAOg4IEFAAIgOA4IhXAAQgGAAgGAEQgGAGgBAFIguC9gAAZA9IA3jkQADgNAMgJQALgKANAAIDGAAQANAAAIAKQAGAJgDANIgcB3QgDANgMAJQgLAJgNAAIivAAIgTBOgACFiLQgFAGgCAFIgJAoQgCAGADAFQAEAFAHAAIB2AAQAHAAAFgFQAGgFACgGIAJgoQACgGgEgFQgDgEgHAAIh2AAQgHAAgGAEgAjdA9QgNAAgHgJQgIgKAEgMIAvjFQAEgOALgIQALgKAOAAIDkAAIgNA4Ii9AAQgHAAgGAEQgFAGgCAFIgHAgIClAAIgNA3IimAAIgHAgQgCAGADAEQAEAFAHAAIC8AAIgNA3gAoiA9IA+kEIDmAAQAOAAAGAKQAHAJgDANIgwDFQgDAMgLAKQgMAJgNAAgAneAGICHAAQAGAAAGgFQAGgDABgHIAdh3QACgFgEgGQgDgEgHAAIiHAAgAqCA9IAqitIi6CtIg/AAIA/kEIA2AAIgqCuIC5iuIBAAAIg/EEgAu1A9IAui9QABgGgDgFQgDgEgHAAIgdAAIjbDMIhNAAIEAjzQAVgRAYAAIBNAAQANAAAHAKQAHAIgDAOIg4Dkg");
	this.shape.setTransform(254.1,32.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.lastSlideLogo, new cjs.Rectangle(0,0,508.3,64.3), null);


(lib.flexibilitytitle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgnA4IAAhwIAYAAIAAArIAKAAQAUABANAIQAMAJAAAQQAAAjguAAgAgPAlIAIAAQALAAAGgEQAFgEAAgIQAAgIgFgDQgFgEgOAAIgGAAg");
	this.shape.setTransform(78.6,5.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLA4IAAhbIgeAAIAAgVIBTAAIAAAVIgeAAIAABbg");
	this.shape_1.setTransform(68.6,5.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdArQgNgQAAgbQAAgRAGgNQAHgNAMgHQALgHAQAAQAQAAARAHIgIAUIgMgFQgHgDgGAAQgNAAgHALQgIAKAAARQAAAmAcAAQAMAAARgGIAAAUQgOAGgSAAQgXAAgNgPg");
	this.shape_2.setTransform(59.1,5.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnArQgOgOAAgdQAAgbAOgPQAOgPAZAAQAaAAAOAPQAOAPAAAbQAAAdgOAOQgOAPgaAAQgZAAgOgPgAgUgcQgIAKAAASQAAATAHAKQAIAJANAAQAdAAAAgmQAAglgdAAQgNAAgHAJg");
	this.shape_3.setTransform(47.6,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AATA4Igog4IAAA4IgYAAIAAhwIAYAAIAAA3IAng3IAaAAIgpA2IArA6g");
	this.shape_4.setTransform(36.7,5.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgnA4IAAhwIBHAAIAAAUIgvAAIAAAXIAKAAQAVABAMAIQAMAIAAARQAAAjguAAgAgPAlIAIAAQALAAAGgEQAGgEAAgIQAAgIgGgDQgFgEgOAAIgGAAg");
	this.shape_5.setTransform(25.9,5.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAeA4IABhVIAAAAIg0BVIgdAAIAAhwIAWAAIgBBVIAAAAIAzhVIAdAAIAABwg");
	this.shape_6.setTransform(14,5.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgjA4IAAhwIBHAAIAAAUIgvAAIAABcg");
	this.shape_7.setTransform(3.6,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.flexibilitytitle, new cjs.Rectangle(0,0,82.6,11.7), null);


(lib.flexibilitysubtitle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAdA5IAAgdIg6AAIAAAdIgMAAIAAgpIAHAAQAKgOAGgRQAGgTAAgWIAqAAIAABIIAMAAIAAApgAgHgMQgGASgIAKIAnAAIAAg+IgSAAQgBAQgGASg");
	this.shape.setTransform(49.5,30.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUAnQgJgGgEgJQgFgKAAgOQAAgTAKgNQALgLARAAQASAAALAMQAKAMAAATQAAAVgKAMQgLALgSAAQgLAAgJgFgAgSgYQgHAJABAPQgBARAHAIQAGAJAMAAQANAAAGgJQAGgIAAgRQAAgPgGgJQgGgIgNAAQgMAAgGAIg");
	this.shape_1.setTransform(40.2,28.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAYAqIgYgiIgXAiIgOAAIAegqIgcgpIAOAAIAVAgIAWggIAPAAIgdApIAeAqg");
	this.shape_2.setTransform(31.3,28.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAdA5IAAgdIg6AAIAAAdIgMAAIAAgpIAHAAQAKgPAGgQQAFgTABgWIAqAAIAABIIAMAAIAAApgAgHgMQgGASgJAKIAoAAIAAg+IgSAAQgCATgFAPg");
	this.shape_3.setTransform(22.6,30.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTAnQgJgGgFgJQgFgKAAgOQAAgTAKgNQALgLARAAQATAAAJAMQALAMAAATQAAAUgKANQgLALgSAAQgLAAgIgFgAgSgYQgHAKAAAOQAAAQAHAJQAHAJALAAQAMAAAHgJQAHgIAAgRQAAgPgHgJQgHgIgMAAQgLAAgHAIg");
	this.shape_4.setTransform(13.3,28.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAXAqIAAhIIgtAAIAABIIgNAAIAAhTIBHAAIAABTg");
	this.shape_5.setTransform(3.6,28.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAZA8IAAhHIgtBHIgQAAIAAhUIANAAIgBBHIAthHIAQAAIAABUgAgUgpQgGgFgBgNIAMAAQABAJADACQADAEAIAAQAIAAAEgEQADgDACgIIAMAAQgBAMgHAGQgHAGgOAAQgNAAgHgGg");
	this.shape_6.setTransform(130.4,6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAiAqIAAhTIANAAIAABTgAguAqIAAhTIAMAAIAAAjIAXAAQAQAAAHAGQAIAFAAAMQAAANgIAGQgIAGgPAAgAgiAgIAWAAQAUAAAAgPQAAgGgFgEQgDgDgMAAIgWAAg");
	this.shape_7.setTransform(119.3,7.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAYAqIAAgmIgvAAIAAAmIgMAAIAAhTIAMAAIAAAjIAvAAIAAgjIAMAAIAABTg");
	this.shape_8.setTransform(108.2,7.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgjAqIAAhTIANAAIAAAjIAZAAQAhAAAAAXQAAAMgJAHQgIAGgQAAgAgWAgIAYAAQALAAAFgEQAFgEAAgHQAAgGgFgEQgFgDgLAAIgYAAg");
	this.shape_9.setTransform(98.7,7.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AglAqIAAgKIAEABQAJAAAFgTQAFgRADgnIAxAAIAABUIgNAAIAAhJIgZAAQgCAcgEAPQgEARgFAGQgGAIgJAAg");
	this.shape_10.setTransform(88.7,7.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaAlQgHgGAAgMQAAgZAogBIAOAAIAAgGQAAgLgEgDQgFgGgJAAQgIABgPAGIgDgJQAEgDAJgDQAHgCAHAAQAPAAAIAHQAHAHAAAOIAAA5IgKAAIgCgMIgBAAQgFAHgHAEQgHADgIAAQgMAAgIgHgAAIABQgOABgHAEQgHAEAAAJQAAAHAFADQAEAEAHAAQAMAAAGgGQAHgHAAgMIAAgHg");
	this.shape_11.setTransform(80.1,7.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgmA8IAAgLIAKACQANAAAGgPIAEgMIgihVIAOAAIASAxQAGAOABAIIABAAIAZhHIAOAAIglBgQgEAOgHAGQgJAHgJAAg");
	this.shape_12.setTransform(72,9.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAdA5IAAgdIg6AAIAAAdIgMAAIAAgoIAHAAQAKgOAGgTQAFgRABgXIAqAAIAABJIAMAAIAAAogAgHgLQgGAQgIAMIAnAAIAAg/IgSAAQgCATgFAQg");
	this.shape_13.setTransform(63.5,9.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAYAqIABhHIgtBHIgPAAIAAhTIAMAAIgBBDIAAAEIAthHIAQAAIAABTg");
	this.shape_14.setTransform(53.9,7.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgjAqIAAhTIAkAAQAgAAAAAVQAAAIgFAFQgFAEgIABIAAABQALABAFAEQAFAGAAAIQAAAMgJAGQgJAGgRAAgAgWAgIAWAAQAXAAAAgPQAAgGgGgEQgFgDgMAAIgWAAgAgWgGIAWAAQALAAAEgDQAFgDAAgHQAAgGgFgDQgFgCgJAAIgXAAg");
	this.shape_15.setTransform(44.8,7.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAZAqIAAhHIgsBHIgQAAIAAhTIALAAIAABDIgBAEIAthHIAQAAIAABTg");
	this.shape_16.setTransform(34.9,7.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAdA5IAAgdIg6AAIAAAdIgMAAIAAgoIAHAAQAKgOAGgTQAGgSAAgWIAqAAIAABJIAMAAIAAAogAgHgLQgGARgIALIAnAAIAAg/IgSAAQgCASgFARg");
	this.shape_17.setTransform(25.3,9.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAYAqIAAgmIgvAAIAAAmIgMAAIAAhTIAMAAIAAAjIAvAAIAAgjIANAAIAABTg");
	this.shape_18.setTransform(15.8,7.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAgA5IAAg+IACggIgBAAIg/BeIgOAAIAAhxIAMAAIgBBeIABAAIA+heIAPAAIAABxg");
	this.shape_19.setTransform(4.7,6.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.flexibilitysubtitle, new cjs.Rectangle(0,0,134.1,35.8), null);


(lib.flexibilityicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjgDhQhdhdAAiEQAAiDBdhdQBdhdCDAAQCEAABdBdQBdBdAACDQAACEhdBdQhdBdiEAAQiDAAhdhdgAjRjRQhXBXAAB6QAAB7BXBXQBXBWB6AAQB7AABXhWQBWhXAAh7QAAh6hWhXQhXhWh7AAQh6AAhXBWgAhggeIBghLIAOAUIhLA7IB5CcIgTAPg");
	this.shape.setTransform(31.8,31.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.flexibilityicon, new cjs.Rectangle(0,0,63.7,63.7), null);


(lib.email = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A61AJIAAgRMA1rAAAIAAARg");
	this.shape.setTransform(174.4,41.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhVBGQgLgQAHgeIAbhtIAuAAIgYBhQgEATAEAJQAEAJAOAAQAUAAAKgMQANgOAHgdIAThPIAuAAIgpCoIgjAAIgBgVIgDAAQgKALgOAHQgPAGgRAAQgeAAgMgQg");
	this.shape_1.setTransform(340.9,26.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhLBWIApioIAiAAIAAAcIADAAQALgOAPgIQAQgJAPAAQAKAAAGABIgOArQgGgBgIAAQgWAAgOALQgPAMgFATIgUBWg");
	this.shape_2.setTransform(324.1,26.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXATQgFgHACgMQAEgMAIgGQAJgHAMAAQAMAAAGAHQAEAHgDALQgCAMgJAHQgIAHgMAAQgNAAgFgHg");
	this.shape_3.setTransform(310.2,33);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag6BVQgMgCgLgFIAKgmQALAGAQAEQAPAEAMAAQAYAAADgPQABgFgCgDQgCgEgHgEIgTgKQgRgIgIgGQgHgHgCgJQgCgJADgNQAFgXAVgMQAUgNAfAAQAfAAAaAOIgWAhIgWgJQgKgDgMAAQgTAAgDALQgBAGAFAEQAFAFAUAJQASAIAHAHQAIAGACAJQACAJgDAMQgGAbgVANQgWAOgjAAQgSAAgNgDg");
	this.shape_4.setTransform(299.6,26.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AASBWIAYhiQAEgSgEgJQgFgJgOAAQgUAAgKANQgMANgHAdIgTBPIgvAAIApioIAjAAIABAWIADAAQALgNAOgGQAPgGARAAQAeAAALAQQAMAQgIAeIgaBtg");
	this.shape_5.setTransform(281.2,26.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhOBKQgKgOAGgaQAGgbAWgLQAWgNAlgCIAegBIACgHQAGgagaAAQgTAAgfANIgHggQAggPAjAAQAiAAAPAPQAOAPgHAeIgbBwIghAAIgDgXIgBAAQgPAOgNAGQgOAGgTAAQgZAAgLgOgAAKAHQgTABgLAGQgLAHgEANQgEAUAWAAQAQAAALgJQAMgJADgQIAEgOg");
	this.shape_6.setTransform(261.6,26.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhLBWIApioIAiAAIAAAcIADAAQALgOAPgIQAQgJAPAAQAKAAAGABIgOArQgGgBgIAAQgWAAgOALQgPAMgFATIgUBWg");
	this.shape_7.setTransform(247.3,26.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag4BaQgJgOAHgcIAThQIgWAAIAFgUIAdgPIAWgkIAdAAIgJAkIAvAAIgIAjIgvAAIgTBQQgCAKAEAFQAEAEAIAAQAMAAATgFIgJAjQgSAHgZAAQgbAAgKgOg");
	this.shape_8.setTransform(234,25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhLBWIApioIAiAAIAAAcIADAAQALgOAPgIQAQgJAPAAQAKAAAGABIgOArQgGgBgIAAQgWAAgOALQgPAMgFATIgUBWg");
	this.shape_9.setTransform(219.7,26.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhHBBQgRgWAKgqQAKgpAbgXQAbgYAkAAQAkAAAPAVQAPAUgIAkIgGAWIhsAAQgEATAIALQAJALATAAQAOAAAPgDQAOgDARgHIgJAkQgOAGgOADQgOADgTAAQgpAAgSgXgAgJgsQgLAJgFARIA/AAQAEgRgGgJQgHgKgOAAQgPAAgJAKg");
	this.shape_10.setTransform(202.8,26.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhcBgQgMgXAKgpQAKgpAXgXQAXgXAeAAQAfAAALAZIACAAQABgTADgPIANg2IAuAAIg4DqIgkAAIgDgWIgCAAQgVAZggAAQgeAAgLgXgAgdgEQgNAMgGAZQgGAZAGAMQAGAMAQAAQARAAAKgKQALgKAHgZIABgFQAHgbgGgLQgGgMgSAAQgPAAgLAOg");
	this.shape_11.setTransform(184.8,23.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgxB2IAoioIAuAAIgoCogAAAheQAFgXAZAAQAZAAgFAXQgDALgIAGQgHAFgNAAQgYAAAFgWg");
	this.shape_12.setTransform(169.9,23.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgyB2IA3jrIAuAAIg3Drg");
	this.shape_13.setTransform(160.6,23.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhxBdQgZgeANg2QAJgkAYgfQAYgeAigSQAigRAnAAQAiAAAWAOQAXANAJAZQAIAagIAgQgGAVgLASQgLASgPALQgQAKgQAAQgLAAgIgFQgHgGgCgJIgCAAQgVAUgZAAQgaAAgMgQQgMgQAHgcQAIgfAZgUQAZgTAgAAQANAAAPACQAPADAJADIgVBJQgFAVALAAQAKAAAJgOQAJgOAGgWQAGgYgGgTQgGgTgQgJQgQgKgXAAQgfAAgZAMQgZANgSAYQgSAXgHAeQgKAqARAWQARAXAqAAQAQAAATgEQAUgDAUgHIgHAdQgjAOgmAAQg6AAgZgfgAgOgaQgNAMgFATQgIAgAaAAQAOAAAJgJQAJgKAHgVIAKghQgHgCgKAAQgSAAgOAMg");
	this.shape_14.setTransform(141.5,25.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhVBVIAHgbIBmhqIhIAAIAIgjIB+AAIgHAdIhlBnIBOAAIgIAkg");
	this.shape_15.setTransform(119.5,26.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag9BNQgQgLgFgUQgFgUAGgaQAKgpAbgXQAbgXAnAAQAYAAAQALQAQALAFATQAGAUgHAaQgKApgbAXQgbAYgmAAQgZAAgQgLgAgRglQgLANgGAYQgGAZAGANQAEANATAAQARAAAMgNQALgNAGgZQAGgYgFgNQgFgMgTAAQgRAAgMAMg");
	this.shape_16.setTransform(102.8,26.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag/BVIgYioIAwAAIAKBeQABATgDAQIABAAQAEgOALgVIA3heIAwAAIhoCog");
	this.shape_17.setTransform(86.4,26.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhHBBQgRgWAKgqQAKgpAbgXQAbgYAkAAQAkAAAPAVQAPAUgIAkIgGAWIhsAAQgEATAIALQAJALATAAQAOAAAPgDQAOgDARgHIgJAkQgOAGgOADQgOADgTAAQgpAAgSgXgAgJgsQgLAJgFARIA/AAQAEgRgGgJQgHgKgOAAQgPAAgJAKg");
	this.shape_18.setTransform(67.2,26.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhLBWIApioIAiAAIAAAcIADAAQALgOAPgIQAQgJAPAAQAKAAAGABIgOArQgGgBgIAAQgWAAgOALQgPAMgFATIgUBWg");
	this.shape_19.setTransform(52.3,26.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhHBBQgRgWAKgqQAKgpAbgXQAbgYAkAAQAkAAAPAVQAPAUgIAkIgGAWIhsAAQgEATAIALQAJALATAAQAOAAAPgDQAOgDARgHIgJAkQgOAGgOADQgOADgTAAQgpAAgSgXgAgJgsQgLAJgFARIA/AAQAEgRgGgJQgHgKgOAAQgPAAgJAKg");
	this.shape_20.setTransform(35.4,26.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhfBvIA2jdIBFAAQApAAAQASQARARgJAiQgIAkgbASQgbATgoAAIgUAAIgTBPgAgUgFIAPAAQAVAAANgJQANgJAEgQQAEgQgHgIQgHgIgUAAIgUAAg");
	this.shape_21.setTransform(17,24.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.email, new cjs.Rectangle(0,0,359.3,46.3), null);


(lib.controlmonitoringtext = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaA4IAohvIAOAAIgqBvg");
	this.shape.setTransform(141.8,26.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AANA5IAAgaIg2AAIAAgLIA0hMIAPAAIAABLIAQAAIAAAMIgQAAIAAAagAAGgeIgiAxIApAAIABg9IgBAAIgHAMg");
	this.shape_1.setTransform(158.3,26.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgkA5IAAgLIAdgeQANgNAEgFIAHgMQACgEAAgIQAAgJgGgFQgFgFgIAAQgIAAgGACQgHACgHAGIgGgIQAPgNATAAQAOAAAKAIQAIAIAAAOQAAALgFAKQgGAJgSARIgXAYIAAABIA5AAIAAALg");
	this.shape_2.setTransform(149.2,26.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgjAzIAAgMQAGAEAIABQAHACAJAAQANAAAHgGQAHgGAAgNQAAgWgcAAQgJAAgKABIgHgDIAEg1IA4AAIAAAMIgtAAIgDAiQAIgCAKAAQARAAAKAJQALAIAAAPQAAARgMAKQgKAKgTAAQgTAAgLgGg");
	this.shape_3.setTransform(134.4,26.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgaAtQgKgNAAgYQAAggANgRQANgQAYAAQAJAAAFACIAAAKQgFgBgIAAQgRAAgKALQgKALgBAYIABAAQAJgNARAAQAPAAAJAKQAJAIAAAPQAAATgKAJQgJAKgRAAQgRAAgKgNgAgKAAQgHADgCAEQgEAFAAAFQAAAJADAHQADAGAGAFQAGADAGAAQALAAAGgGQAGgHAAgOQAAgKgFgIQgGgEgLAAQgHAAgFACg");
	this.shape_4.setTransform(125.4,26.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWA5QgIgBgGgEIAAgMQAFADAKACIAQACQAcAAAAgWQAAgWgeAAIgMAAIAAgKIAMAAQAMABAHgGQAIgGAAgKQAAgIgGgGQgFgEgJAAQgIAAgGACQgHABgIAHIgGgJQAGgGAJgDQAJgDALAAQAPAAAJAHQAJAIAAANQAAAMgFAGQgHAHgLACIAAABQAPABAFAHQAHAGAAAMQAAAPgLAKQgLAIgUAAIgRgBg");
	this.shape_5.setTransform(116.2,26.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAzAAIAAALIgmAAIAABIg");
	this.shape_6.setTransform(104.8,27.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAYAqIAAgmIgvAAIAAAmIgMAAIAAhTIAMAAIAAAjIAvAAIAAgjIANAAIAABTg");
	this.shape_7.setTransform(95.8,27.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZAqIABhHIgtBHIgQAAIAAhTIALAAIAABHIAshHIARAAIAABTg");
	this.shape_8.setTransform(85.8,27.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgkA+IAAh6IAKAAIACAMIABAAQAEgHAHgDQAGgDAIAAQASAAAIAMQAJALAAAUQAAAVgJALQgJALgRABQgHAAgHgDQgHgEgEgFIgBAAIABAwgAgRgrQgGAHAAAQIAAACQAAASAGAHQAFAIANAAQALAAAGgJQAGgIAAgQQAAgOgGgKQgGgJgMAAQgMAAgFAIg");
	this.shape_9.setTransform(76.1,29.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgUAnQgIgFgFgLQgFgJAAgOQAAgUAKgLQAKgMASAAQATAAAJAMQALAMAAATQAAAVgLALQgJAMgTAAQgLAAgJgFgAgSgYQgHAIAAAQQAAARAHAIQAGAIAMAAQANAAAGgIQAGgIAAgRQAAgQgGgIQgGgIgNAAQgMAAgGAIg");
	this.shape_10.setTransform(66.3,27.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgGAqIAAhIIgbAAIAAgLIBDAAIAAALIgcAAIAABIg");
	this.shape_11.setTransform(57.8,27.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAZAqIAAhHIgsBHIgRAAIAAhTIAMAAIAABHIAshHIAQAAIAABTg");
	this.shape_12.setTransform(49.1,27.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAYAqIAAgmIgvAAIAAAmIgNAAIAAhTIANAAIAAAjIAvAAIAAgjIANAAIAABTg");
	this.shape_13.setTransform(39,27.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgUAnQgIgFgFgLQgFgLAAgMQAAgUAKgLQAKgMATAAQARAAALAMQAKAMAAATQAAAVgKALQgLAMgSAAQgLAAgJgFgAgSgYQgGAIAAAQQAAARAGAIQAHAIALAAQANAAAGgIQAHgJAAgQQAAgPgHgJQgGgIgNAAQgMAAgGAIg");
	this.shape_14.setTransform(29.2,27.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAhAqIAAhFIgcBFIgKAAIgbhFIAABFIgLAAIAAhTIAPAAIAcBHIAchHIARAAIAABTg");
	this.shape_15.setTransform(18.6,27.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAYAqIABhHIgtBHIgPAAIAAhTIALAAIAABHIAshHIARAAIAABTg");
	this.shape_16.setTransform(3.7,27.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgjAqIAAhTIANAAIAAAjIAZAAQAhAAAAAWQAAANgJAGQgIAHgQAAgAgWAfIAYAAQAKAAAGgDQAFgDAAgIQAAgHgFgDQgFgDgLAAIgYAAg");
	this.shape_17.setTransform(68.6,7.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AglAqIAAgJIAEAAQAJAAAFgTQAGgRACgnIAxAAIAABUIgNAAIAAhJIgZAAQgBAcgFAPQgEAQgFAHQgGAIgJAAg");
	this.shape_18.setTransform(58.5,7.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgUAnQgJgHgEgJQgFgLAAgMQAAgUAKgLQALgMARAAQASAAALAMQAKAMAAATQAAAUgKAMQgLAMgSAAQgKAAgKgFgAgSgYQgHAJABAPQgBARAHAHQAGAJAMAAQANAAAHgJQAGgIAAgQQAAgPgGgIQgIgJgMAAQgMAAgGAIg");
	this.shape_19.setTransform(49.8,7.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgkA+IAAh6IAKAAIACAMIAAAAQAGgHAGgDQAGgDAIAAQARAAAJALQAJAMAAAVQAAAUgJALQgJAMgRAAQgHAAgHgDQgFgDgHgHIAAAAIAAAxgAgSgrQgFAHgBAQIAAADQAAARAGAHQAGAIANAAQALAAAGgJQAGgIAAgPQAAgQgGgJQgGgIgMAAQgMAAgGAHg");
	this.shape_20.setTransform(40.4,8.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgGAqIAAhJIgbAAIAAgKIBDAAIAAAKIgcAAIAABJg");
	this.shape_21.setTransform(31.6,7.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAYAqIAAgmIgvAAIAAAmIgMAAIAAhTIAMAAIAAAjIAvAAIAAgjIANAAIAABTg");
	this.shape_22.setTransform(22.9,7.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgUAnQgIgGgFgKQgFgLAAgMQAAgUALgLQAKgMASAAQARAAALAMQAKAMAAATQAAAUgKAMQgLAMgSAAQgKAAgKgFgAgSgYQgGAJAAAPQAAARAGAHQAHAJALAAQAOAAAFgJQAHgHAAgRQAAgQgHgHQgGgJgNAAQgMAAgGAIg");
	this.shape_23.setTransform(13.1,7.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAZA4Ig0g4IAAA4IgNAAIAAhvIANAAIAAA2IAyg2IAPAAIgxA2IA0A5g");
	this.shape_24.setTransform(4.3,5.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.controlmonitoringtext, new cjs.Rectangle(0,0,162.5,35.9), null);


(lib.clockicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjgDhQhdhdAAiEQAAiDBdhdQBdhdCDAAQCEAABdBdQBdBdAACDQAACEhdBdQhdBdiEAAQiDAAhdhdgAjRjQQhXBWAAB6QAAB7BXBXQBXBWB6AAQB7AABXhWQBWhXAAh7QAAh6hWhWQhXhXh7AAQh6AAhXBXgAiEADIAAgYIB6AAIAAjBIAYAAIAADZg");
	this.shape.setTransform(31.8,31.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.clockicon, new cjs.Rectangle(0,0,63.7,63.7), null);


(lib.butt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("EiV/ATiMAAAgnDMEr/AAAMAAAAnDg");
	this.shape.setTransform(960,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.slide2text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_18 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(18).call(this.frame_18).wait(12));

	// Symbol 4
	this.instance = new lib.Symbol4();
	this.instance.parent = this;
	this.instance.setTransform(90,70.6,1,1,0,0,0,102,9.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({x:102,alpha:1},9,cjs.Ease.get(1)).wait(12));

	// Symbol 3
	this.instance_1 = new lib.Symbol3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(116.9,42.3,1,1,0,0,0,128.9,11.7);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({_off:false},0).to({x:128.9,alpha:1},9,cjs.Ease.get(1)).wait(17));

	// Symbol 2
	this.instance_2 = new lib.Symbol2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(79,9.1,1,1,0,0,0,91,9.1);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:91,alpha:1},9,cjs.Ease.get(1)).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,0,182.2,18.2);


(lib.slide2bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1();
	this.instance.parent = this;
	this.instance.setTransform(960,125,1,1,0,0,0,960,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.slide2bg, new cjs.Rectangle(0,0,1920,250), null);


(lib.secondSlide = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_89 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(89).call(this.frame_89).wait(1));

	// rabota-est
	this.instance = new lib.rabotaest();
	this.instance.parent = this;
	this.instance.setTransform(925.6,157.3,1,1,0,0,0,159.4,25.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(51).to({_off:false},0).to({x:937.6,alpha:1},10,cjs.Ease.get(1)).wait(29));

	// ot-eurofuru
	this.instance_1 = new lib.oteurofuru();
	this.instance_1.parent = this;
	this.instance_1.setTransform(906.9,92.8,1,1,0,0,0,126.3,25.9);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(41).to({_off:false},0).to({x:918.9,alpha:1},10,cjs.Ease.get(1)).wait(39));

	// slide2text
	this.instance_2 = new lib.slide2text();
	this.instance_2.parent = this;
	this.instance_2.setTransform(578.4,125,1,1,0,0,0,128.9,39.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(24).to({_off:false},0).wait(66));

	// plashka1
	this.instance_3 = new lib.plashka1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(316.7,125,1,1,0,0,0,387.2,73.7);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({_off:false},0).to({x:387.2},10).wait(66));

	// slide2-bg
	this.instance_4 = new lib.slide2bg();
	this.instance_4.parent = this;
	this.instance_4.setTransform(960,125,1,1,0,0,0,960,125);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({alpha:1},14).wait(76));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1920,250);


(lib.lastSlidebg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(960,125,1,1,0,0,0,960,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.lastSlidebg, new cjs.Rectangle(0,0,1920,250), null);


(lib.lastSlide = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// email
	this.instance = new lib.email();
	this.instance.parent = this;
	this.instance.setTransform(1272.4,139.4,1,1,0,0,0,179.6,23.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(109).to({_off:false},0).to({x:1248.4,alpha:1},10,cjs.Ease.get(1)).wait(46).to({x:1381.4,alpha:0},10).to({_off:true},1).wait(15));

	// phone
	this.instance_1 = new lib.phone();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1232.1,93.2,1,1,0,0,0,129.9,23.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(104).to({_off:false},0).to({x:1208.1,alpha:1},10,cjs.Ease.get(1)).wait(51).to({x:1341.1,alpha:0},10).to({_off:true},1).wait(15));

	// lastSlideLogo
	this.instance_2 = new lib.lastSlideLogo();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1358.1,125,1,1,0,0,0,254.1,32.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(29).to({_off:false},0).to({x:1217.9,alpha:1},15,cjs.Ease.get(1)).wait(45).to({x:1286.1,alpha:0},15,cjs.Ease.get(1)).to({_off:true},1).wait(86));

	// lastSlidePlashka
	this.instance_3 = new lib.lastSlidePlashka();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1548.3,115.6,1,1,0,0,0,514.3,73.7);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({_off:false},0).to({x:1405.8,alpha:1},15,cjs.Ease.get(1)).wait(62).to({x:1521},13,cjs.Ease.get(-1)).wait(61).to({x:1654,alpha:0},10).to({_off:true},1).wait(15));

	// lastSlide-bg
	this.instance_4 = new lib.lastSlidebg();
	this.instance_4.parent = this;
	this.instance_4.setTransform(960,125,1,1,0,0,0,960,125);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({alpha:1},14).wait(161).to({alpha:0},14).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1920,250);


(lib.firstSlide = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_194 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(194).call(this.frame_194).wait(1));

	// flexibility-subtitle
	this.instance = new lib.flexibilitysubtitle();
	this.instance.parent = this;
	this.instance.setTransform(1432.7,138.1,1,1,0,0,0,67,17.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(136).to({_off:false},0).to({x:1402.7,alpha:1},6,cjs.Ease.get(1)).wait(26).to({x:1427.2,alpha:0},10,cjs.Ease.get(1)).wait(17));

	// flexibility-title
	this.instance_1 = new lib.flexibilitytitle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1407,99.9,1,1,0,0,0,41.3,5.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(132).to({_off:false},0).to({x:1377,alpha:1},6,cjs.Ease.get(1)).wait(30).to({x:1401.5,alpha:0},10,cjs.Ease.get(1)).wait(17));

	// flexibility-icon
	this.instance_2 = new lib.flexibilityicon();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1280.5,125,0.3,0.3,0,0,0,31.9,31.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(123).to({_off:false},0).to({regX:31.8,regY:31.8,scaleX:1.3,scaleY:1.3},5).to({scaleX:0.8,scaleY:0.8},5).to({scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(30).to({x:1305,alpha:0},10,cjs.Ease.get(1)).wait(17));

	// strah-ppolis
	this.instance_3 = new lib.strahppolis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1147.6,138.1,1,1,0,0,0,65.8,18.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(117).to({_off:false},0).to({x:1117.6,alpha:1},6,cjs.Ease.get(1)).wait(45).to({x:1142.1,alpha:0},10,cjs.Ease.get(1)).wait(17));

	// otvetstvennost
	this.instance_4 = new lib.otvetstvennost();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1158.7,99.5,1,1,0,0,0,76.9,5.8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(113).to({_off:false},0).to({x:1128.7,alpha:1},6,cjs.Ease.get(1)).wait(49).to({x:1153.2,alpha:0},10,cjs.Ease.get(1)).wait(17));

	// otv-icon
	this.instance_5 = new lib.otvicon();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1002.3,125,0.3,0.3,0,0,0,26.2,31.9);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(104).to({_off:false},0).to({regX:26.1,regY:31.8,scaleX:1.3,scaleY:1.3},5).to({regX:26.2,scaleX:0.8,scaleY:0.8},5).to({regX:26.1,scaleX:1,scaleY:1},5,cjs.Ease.get(1)).wait(49).to({x:1026.8,alpha:0},10,cjs.Ease.get(1)).wait(17));

	// clock-icon
	this.instance_6 = new lib.clockicon();
	this.instance_6.parent = this;
	this.instance_6.setTransform(1004.9,124.8,0.3,0.3,0,0,0,31.9,32);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(14).to({_off:false},0).to({regX:31.8,regY:31.9,scaleX:1.3,scaleY:1.3,y:124.9},5).to({scaleX:0.8,scaleY:0.8,y:124.8},5).to({regX:31.9,scaleX:1,scaleY:1,x:1005,y:124.9},6,cjs.Ease.get(1)).wait(64).to({x:1029,alpha:0},10).to({_off:true},1).wait(90));

	// control-monitoring-text
	this.instance_7 = new lib.controlmonitoringtext();
	this.instance_7.parent = this;
	this.instance_7.setTransform(1156.3,138.1,1,1,0,0,0,81.3,17.9);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(30).to({_off:false},0).to({x:1141.3,alpha:1},8,cjs.Ease.get(1)).wait(56).to({x:1165.3,alpha:0},10).to({_off:true},1).wait(90));

	// punctuality-text
	this.instance_8 = new lib.punctualitytext();
	this.instance_8.parent = this;
	this.instance_8.setTransform(1149.6,99.6,1,1,0,0,0,74.6,5.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(26).to({_off:false},0).to({x:1134.6,alpha:1},8,cjs.Ease.get(1)).wait(60).to({x:1158.6,alpha:0},10).to({_off:true},1).wait(90));

	// shield-icon
	this.instance_9 = new lib.shieldicon();
	this.instance_9.parent = this;
	this.instance_9.setTransform(1291.7,124.9,0.3,0.3,0,0,0,25.7,31.9);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(39).to({_off:false},0).to({regX:25.6,regY:31.8,scaleX:1.3,scaleY:1.3,x:1291.8},5).to({scaleX:0.8,scaleY:0.8},5).to({regX:25.5,scaleX:1,scaleY:1,x:1291.7},5,cjs.Ease.get(1)).wait(40).to({x:1315.7,alpha:0},10).to({_off:true},1).wait(90));

	// voditeli-text
	this.instance_10 = new lib.voditelitext();
	this.instance_10.parent = this;
	this.instance_10.setTransform(1420.8,138.1,1,1,0,0,0,60.6,17.9);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(54).to({_off:false},0).to({x:1401.3,alpha:1},8,cjs.Ease.get(1)).wait(32).to({x:1425.3,alpha:0},10).to({_off:true},1).wait(90));

	// security
	this.instance_11 = new lib.Symbol1();
	this.instance_11.parent = this;
	this.instance_11.setTransform(1423.5,99.6,1,1,0,0,0,63.3,5.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(49).to({_off:false},0).to({x:1404,alpha:1},8,cjs.Ease.get(1)).wait(37).to({x:1428,alpha:0},10).to({_off:true},1).wait(90));

	// Layer_5
	this.instance_12 = new lib.plashka();
	this.instance_12.parent = this;
	this.instance_12.setTransform(1813.6,125,1,1,0,0,0,514.3,73.7);
	this.instance_12.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({x:1405.8,alpha:1},14,cjs.Ease.get(1)).wait(160).to({x:1479.3,alpha:0},10,cjs.Ease.get(-1)).wait(11));

	// background
	this.instance_13 = new lib.ClipGroup_2();
	this.instance_13.parent = this;
	this.instance_13.setTransform(960,125,1,1,0,0,0,960,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(195));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,2327.8,250);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.button.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open("http://xn--80ahdkoqtalg.xn--p1ai/", "_blank");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(503));

	// button
	this.button = new lib.butt();
	this.button.name = "button";
	this.button.parent = this;
	this.button.setTransform(960,125,1,1,0,0,0,960,125);
	new cjs.ButtonHelper(this.button, 0, 1, 2, false, new lib.butt(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button).to({_off:true},502).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("Egu3gR9MBdvAAAMAAAAj7MhdvAAAg");
	this.shape.setTransform(960,125,3.2,1.087);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},502).wait(1));

	// Last slide
	this.instance = new lib.lastSlide();
	this.instance.parent = this;
	this.instance.setTransform(960,125,1,1,0,0,0,960,125);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(311).to({_off:false},0).to({_off:true},191).wait(1));

	// Slide 3
	this.instance_1 = new lib.secondSlide();
	this.instance_1.parent = this;
	this.instance_1.setTransform(960,125,1,1,0,0,0,960,125);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(194).to({_off:false},0).to({_off:true},135).wait(174));

	// First slide
	this.instance_2 = new lib.firstSlide();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1163.9,125.1,1,1,0,0,0,1163.9,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},209).wait(294));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(959,124,2328.8,252);
// library properties:
lib.properties = {
	id: '826AFDA4B755504A9FE5FE6D4D4EBEA7',
	width: 1920,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"Image.png", id:"Image"},
		{src:"Image_1.png", id:"Image_1"},
		{src:"Image_2.png", id:"Image_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['826AFDA4B755504A9FE5FE6D4D4EBEA7'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;